-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 19:04:52 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity cache_fsm_normal is
    port (
        clk : in std_logic;
        reset : in std_logic;
        start : in std_logic;
        rw : in std_logic;                       
        hit : in std_logic; --hit/miss (1 = hit, 0 = miss)
        busy : out std_logic;
        load_in : inout std_logic;    --input registers follow their inputs
        out_load : inout std_logic;   --output register captures selected byte
        out_oe : inout std_logic; --drive byte onto CD
        enable : out std_logic; --ENABLE pin to memory
        ma_oe : out std_logic;  --drive MA
        dec_en : out std_logic; --address_decoder chip_en
        refill : inout std_logic; --1: byte offset from byte_cnt, write data from MD
        byte_cnt : inout std_logic_vector(1 downto 0);    --byte being refilled
        data_wr : out std_logic;    --data cell write, BEFORE rising-edge retiming
        tv_wr : out std_logic   --tag + valid write, BEFORE rising-edge retiming
    );
end cache_fsm_normal;
