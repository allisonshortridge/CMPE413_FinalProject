-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 17:10:26 2026


architecture structural of inverter is

begin

  output <= not (input);

end structural;
