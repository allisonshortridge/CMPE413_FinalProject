-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:24:24 2026


library STD;
library ieee;
use ieee.std_logic_1164.all;

entity cd_reg is
    port (
        ca   : in  std_logic_vector(7 downto 0);
        load : in  std_logic;
        clk  : in  std_logic;
        q    : out std_logic_vector(7 downto 0)
    );
end cd_reg;
