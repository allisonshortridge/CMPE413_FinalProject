-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:01:54 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity address_decoder is
    port (
        address     :   in std_logic_vector(3 downto 0);
        chip_en     :   in std_logic;
        refill      :   in std_logic;                       -- FSM: take byte offset from byte_cnt
        byte_cnt    :   in std_logic_vector(1 downto 0);    -- FSM: byte being refilled
        block_en    :   inout std_logic_vector(3 downto 0);
        byte_en     :   inout std_logic_vector(15 downto 0)
    );
end address_decoder;
