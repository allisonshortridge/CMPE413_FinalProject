-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 17:54:46 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;


-- positive level sensitive dlatch
entity positive_dlatch is
    port (
        d   : in  std_logic;
        en : in  std_logic;
        q   : out std_logic;
        qbar: out std_logic
    );
end positive_dlatch;
