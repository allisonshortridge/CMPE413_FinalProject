-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Oct  2 13:35:29 2026


architecture structural of or2 is

begin

  output <= input2 or input1;

end structural;
