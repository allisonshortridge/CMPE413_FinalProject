-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:08:54 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity ma_out is
    port (
        addr_in   : in std_logic_vector(7 downto 0);
        en  : in std_logic;
        y   : out std_logic_vector(7 downto 0)
    );
end ma_out;
