-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:35:32 2026


architecture structural of cache_cell is

-- positive level sensitive latch
component positive_dlatch
    port (
        d   : in  std_logic;
        en : in  std_logic;
        q   : out std_logic;
        qbar: out std_logic
    );
end component;


component inverter
    port (
        input    : in  std_logic;
        output   : out std_logic
    );
end component;

-- transmission gate
component tx
    port ( 
        sel   : in std_logic;
        selnot: in std_logic;
        input : in std_logic;
        output : out std_logic
    );
end component;


-- 1-to-2 decoder
component decoder1to2
    port (
        A0    : in std_logic;
        E     : in std_logic;
        Y1    : out std_logic;
        Y0    : out std_logic
    );
end component;

for positive_dlatch_1: positive_dlatch use entity work.positive_dlatch(structural);
for inverter_1: inverter use entity work.inverter(structural);
for tx_1: tx use entity work.tx(structural);
for decoder1to2_1: decoder1to2 use entity work.decoder1to2(structural);

signal wr_en, rd_en, not_rd_en, dlatch_out: std_logic;

begin

    decoder1to2_1: decoder1to2 port map(rd_wr, chip_en, rd_en, wr_en);

    positive_dlatch_1: positive_dlatch port map(wr_data, wr_en, dlatch_out, open);

    inverter_1: inverter port map(rd_en, not_rd_en);

    tx_1: tx port map(rd_en, not_rd_en, dlatch_out, rd_data);

end structural;