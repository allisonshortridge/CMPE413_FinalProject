-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:35:32 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;


-- 1-bit cache cell
entity cache_cell is
    port (
        wr_data   : in  std_logic;
        chip_en : in  std_logic;
        rd_wr : in std_logic;
        rd_data   : out std_logic
    );
end cache_cell;
