-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Sun Nov 22 15:12:56 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity cache_top is
    port (
        clk : in std_logic;
        reset : in std_logic;
        start : in std_logic;
        rw : in std_logic;  --RD/WR (1 = read, 0 = write)
        ca : in std_logic_vector(5 downto 0);   --CPU address
        cd : inout std_logic_vector(7 downto 0);    --CPU data
        md : in std_logic_vector(7 downto 0);   --memory data
        vdd : in std_logic;
        gnd : in std_logic;
        busy : out std_logic;
        enable : out std_logic; --ENABLE to memory
        ma : out std_logic_vector(5 downto 0)   -- memory address
    );
end cache_top;
