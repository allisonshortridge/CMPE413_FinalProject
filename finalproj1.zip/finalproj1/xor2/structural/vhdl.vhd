-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 17:45:04 2026


architecture structural of xor2 is

begin

  output <= input2 xor input1;

end structural;
