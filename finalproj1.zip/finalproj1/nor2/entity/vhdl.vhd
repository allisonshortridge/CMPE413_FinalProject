-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 17:45:04 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity nor2 is
    port (
        input1  :   in std_logic;
        input2  :   in std_logic;
        output  :   out std_logic
    );
end nor2;
