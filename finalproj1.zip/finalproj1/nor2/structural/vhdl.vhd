-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 17:45:04 2026


architecture structural of nor2 is

component inverter
    port (
        input  : in  std_logic;
        output : out std_logic
    );
end component;

component or2
    port (
        input1 : in  std_logic;
        input2 : in  std_logic;
        output : out std_logic
    );
end component;

for inverter_1: inverter use entity work.inverter(structural);
for or2_1: or2 use entity work.or2(structural);

signal or_output : std_logic;

begin
    or2_1:      or2      port map(input1, input2, or_output);
    inverter_1: inverter port map(or_output, output);
end structural;