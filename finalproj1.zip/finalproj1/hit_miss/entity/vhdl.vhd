-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:08:54 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity hit_miss is
port (
    tag_req     : in std_logic_vector(1 downto 0);
    tag_stored  : in std_logic_vector(1 downto 0);
    valid       : in std_logic;
    hit         : out std_logic
    );
end hit_miss;
