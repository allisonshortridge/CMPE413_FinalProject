-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:24:24 2026


architecture structural of reg is
    component mux
        port (
            input1   : in std_logic;
            input2   : in std_logic;
            sel      : in std_logic;
            y : out std_logic
        );
        end component;

    component ndflip
        port (
            d   : in std_logic;
            clk   : in std_logic;
            rst   : in std_logic;
            q : out std_logic
        );
        end component;

--declaration of individual gates
for mux_1: mux use entity work.mux(structural);
for ndflip_1: ndflip use entity work.ndflip(structural);
--intermediate signals between gates
signal sel_1, q_int: std_logic;

signal gnd: std_logic;

begin
    gnd<='0';
--mapping ports to gates
    mux_1: mux port map(q_int, d, load, sel_1);

    ndflip_1: ndflip port map(sel_1, clk, gnd, q_int);

    q <= q_int;
end structural;
