-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:24:24 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity output_registers is
    port (
        data_in   : in std_logic_vector(7 downto 0);
        load  : in std_logic;
        clk : in std_logic;
        data_out  : out std_logic_vector(7 downto 0)
    );
end output_registers;
