-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 17:54:46 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity tristate_buffer is
    port (
        input1  :   in std_logic;
        en      :   in std_logic;
        output  :   out std_logic
    );
end tristate_buffer;
