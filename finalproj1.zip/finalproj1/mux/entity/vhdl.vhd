-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 17:54:46 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity mux is
    port (
        input1   : in std_logic;
        input2   : in std_logic;
        sel  : in std_logic;
        y   : out std_logic
    );
end mux;
