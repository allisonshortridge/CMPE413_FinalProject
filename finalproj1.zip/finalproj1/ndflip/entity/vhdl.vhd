-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:15:20 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity ndflip is
    port (
        d   : in std_logic;
        clk    : in std_logic;
        rst     :  in std_logic;
        q   : out std_logic
    );
end ndflip;
