-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:35:32 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity lru_unit is
    port (
        wr_data     :   in std_logic_vector(7 downto 0);
        rq_tag      :   in std_logic_vector(1 downto 0);
        block_en    :   in std_logic_vector(3 downto 0);
        byte_en     :   in std_logic_vector(15 downto 0);
        data_wr     :   in std_logic;    -- FSM data_wr, before retiming
        tv_wr       :   in std_logic;    -- FSM tv_wr, before retiming
        refill      :   in std_logic;    -- FSM refill
        lookup      :   in std_logic;    -- FSM out_load: both ways on, way register loads
        way_in      :   in std_logic;    -- hit logic: hit way, or victim on a miss
        rd_done     :   in std_logic;    -- FSM out_oe: a read has finished
        clk         :   in std_logic;
        rst         :   in std_logic;
        gnd         :   in std_logic;
        valid0      :   out std_logic;
        valid1      :   out std_logic;
        tag0        :   out std_logic_vector(1 downto 0);
        tag1        :   out std_logic_vector(1 downto 0);
        rd_data0    :   out std_logic_vector(7 downto 0);
        rd_data1    :   out std_logic_vector(7 downto 0);
        victim      :   out std_logic
    );
end lru_unit;
