-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:35:32 2026


architecture structural of lru_unit is
    

component cache_way
    port (
        wr_data     :   in std_logic_vector(7 downto 0);
        block_en    :   in std_logic_vector(3 downto 0);
        byte_en     :   in std_logic_vector(15 downto 0);
        rd_wr       :   in std_logic;
        vt_en       :   in std_logic;
        wr_valid    :   in std_logic;
        wr_tag      :   in std_logic_vector(1 downto 0);
        valid_bit   :   out std_logic;
        tag         :   out std_logic_vector(1 downto 0);
        rd_data    :   out std_logic_vector(7 downto 0)
    );
end component;

component pdflip
    port (
        d   : in  std_logic;
        clk : in  std_logic;
        rst : in  std_logic;
        q   : out std_logic
    ); 
end component;

component ndflip
    port (
        d   : in  std_logic;
        clk : in  std_logic;
        rst : in  std_logic;
        q   : out std_logic
    );
end component;


component positive_dlatch
    port (
        d    : in  std_logic;
        en   : in  std_logic;
        q    : out std_logic;
        qbar : out std_logic
    );
end component;

component inverter
    port (
        input  : in  std_logic;
        output : out std_logic
    );
end component;

component and2
    port (
        input1 : in  std_logic;
        input2 : in  std_logic;
        output : out std_logic
    );
end component;

component or2
    port (
        input1 : in  std_logic;
        input2 : in  std_logic;
        output : out std_logic
    ); 
end component;


component nor2
    port (
        input1  : in  std_logic;
        input2  : in  std_logic;
        output  : out std_logic
    );
end component;

component mux
    port (
        input1 : in  std_logic;
        input2 : in  std_logic;
        sel    : in  std_logic;
        y      : out std_logic
    );
end component;

for way0, way1: cache_way use entity work.cache_way(structural);
for data_ff, tv_ff, rstp_ff: pdflip use entity work.pdflip(structural);
for way_ff, rstn_ff, rstf_ff: ndflip use entity work.ndflip(structural);
for lru_latch0, lru_latch1, lru_latch2, lru_latch3: positive_dlatch use entity work.positive_dlatch(structural);
for inv_way, inv_v1, inv_clk, inv_ref, inv_wr: inverter use entity work.inverter(structural);
for all: and2 use entity work.and2(structural);
for all: or2 use entity work.or2(structural);
for all: nor2 use entity work.nor2(structural);
for all: mux use entity work.mux(structural);

signal data_q, tv_q, rd_wr, vt_en, wr_valid  : std_logic;
signal rst_f, rst_p, rst_n                   : std_logic;
signal way_i, nway, way_d, nvalid1, v0, v1   : std_logic;
signal nclk, nrefill, upd_rd, upd_wr, lru_upd: std_logic;
signal way_en                                : std_logic_vector(1 downto 0);
signal bw0, bw1, blk0, blk1                  : std_logic_vector(3 downto 0);
signal ben0, ben1                            : std_logic_vector(15 downto 0);
signal lru_wr_en, lru, lru_pick              : std_logic_vector(3 downto 0);
signal pick01, pick23, lru_sel, t_vic        : std_logic;


begin
    
    -- write strobes retimed to the rising edge: low = write, one clock wide
    data_ff: pdflip port map(data_wr, clk, rst, data_q);
    tv_ff:   pdflip port map(tv_wr, clk, rst, tv_q);
    inv_wr:  inverter port map(data_q, rd_wr);

    -- reset invalidation: rst_p is reset sampled on the rising edge, rst_n lags it by half a clock.
    -- wr_valid stays 0 until half a clock after the valid latches close.
    -- reset is first sampled on the falling edge (rst_f), so the rising-edge flop below never samples it
    -- at the same instant the CPU changes it
    rstf_ff: ndflip port map(rst, clk, gnd, rst_f);
    rstp_ff: pdflip port map(rst_f, clk, gnd, rst_p);
    rstn_ff: ndflip port map(rst_p, clk, gnd, rst_n);
    vt_nor:  nor2 port map(tv_q, rst_p, vt_en);
    wv_nor:  nor2 port map(rst_p, rst_n, wr_valid);

    -- way register: loads way_in while lookup is high, otherwise holds
    way_mux: mux port map(way_i, way_in, lookup, way_d);
    way_ff:  ndflip port map(way_d, clk, rst, way_i);
    inv_way: inverter port map(way_i, nway);

    -- lookup enables both ways, otherwise only the held way
    we0_or: or2 port map(lookup, nway, way_en(0));
    we1_or: or2 port map(lookup, way_i, way_en(1));

    -- valid/tag block enables per way; rst_p forces every block on in both ways

    g0_0: and2 port map(block_en(0), way_en(0), bw0(0));
    g1_0: and2 port map(block_en(0), way_en(1), bw1(0));
    r0_0: or2  port map(bw0(0), rst_p, blk0(0));
    r1_0: or2  port map(bw1(0), rst_p, blk1(0));

    g0_1: and2 port map(block_en(1), way_en(0), bw0(1));
    g1_1: and2 port map(block_en(1), way_en(1), bw1(1));
    r0_1: or2  port map(bw0(1), rst_p, blk0(1));
    r1_1: or2  port map(bw1(1), rst_p, blk1(1));

    g0_2: and2 port map(block_en(2), way_en(0), bw0(2));
    g1_2: and2 port map(block_en(2), way_en(1), bw1(2));
    r0_2: or2  port map(bw0(2), rst_p, blk0(2));
    r1_2: or2  port map(bw1(2), rst_p, blk1(2));

    g0_3: and2 port map(block_en(3), way_en(0), bw0(3));
    g1_3: and2 port map(block_en(3), way_en(1), bw1(3));
    r0_3: or2  port map(bw0(3), rst_p, blk0(3));
    r1_3: or2  port map(bw1(3), rst_p, blk1(3));

    -- data byte enables per way, so a write only reaches the held way

    b0_0:  and2 port map(byte_en(0),  way_en(0), ben0(0));
    b1_0:  and2 port map(byte_en(0),  way_en(1), ben1(0));
    b0_1:  and2 port map(byte_en(1),  way_en(0), ben0(1));
    b1_1:  and2 port map(byte_en(1),  way_en(1), ben1(1));
    b0_2:  and2 port map(byte_en(2),  way_en(0), ben0(2));
    b1_2:  and2 port map(byte_en(2),  way_en(1), ben1(2));
    b0_3:  and2 port map(byte_en(3),  way_en(0), ben0(3));
    b1_3:  and2 port map(byte_en(3),  way_en(1), ben1(3));
    b0_4:  and2 port map(byte_en(4),  way_en(0), ben0(4));
    b1_4:  and2 port map(byte_en(4),  way_en(1), ben1(4));
    b0_5:  and2 port map(byte_en(5),  way_en(0), ben0(5));
    b1_5:  and2 port map(byte_en(5),  way_en(1), ben1(5));
    b0_6:  and2 port map(byte_en(6),  way_en(0), ben0(6));
    b1_6:  and2 port map(byte_en(6),  way_en(1), ben1(6));
    b0_7:  and2 port map(byte_en(7),  way_en(0), ben0(7));
    b1_7:  and2 port map(byte_en(7),  way_en(1), ben1(7));
    b0_8:  and2 port map(byte_en(8),  way_en(0), ben0(8));
    b1_8:  and2 port map(byte_en(8),  way_en(1), ben1(8));
    b0_9:  and2 port map(byte_en(9),  way_en(0), ben0(9));
    b1_9:  and2 port map(byte_en(9),  way_en(1), ben1(9));
    b0_10: and2 port map(byte_en(10), way_en(0), ben0(10));
    b1_10: and2 port map(byte_en(10), way_en(1), ben1(10));
    b0_11: and2 port map(byte_en(11), way_en(0), ben0(11));
    b1_11: and2 port map(byte_en(11), way_en(1), ben1(11));
    b0_12: and2 port map(byte_en(12), way_en(0), ben0(12));
    b1_12: and2 port map(byte_en(12), way_en(1), ben1(12));
    b0_13: and2 port map(byte_en(13), way_en(0), ben0(13));
    b1_13: and2 port map(byte_en(13), way_en(1), ben1(13));
    b0_14: and2 port map(byte_en(14), way_en(0), ben0(14));
    b1_14: and2 port map(byte_en(14), way_en(1), ben1(14));
    b0_15: and2 port map(byte_en(15), way_en(0), ben0(15));
    b1_15: and2 port map(byte_en(15), way_en(1), ben1(15));


    way0: cache_way port map(wr_data, blk0, ben0, rd_wr, vt_en, wr_valid, rq_tag, v0, tag0, rd_data0);
    way1: cache_way port map(wr_data, blk1, ben1, rd_wr, vt_en, wr_valid, rq_tag, v1, tag1, rd_data1);
    vb0: and2 port map(v0, v0, valid0);
    vb1: and2 port map(v1, v1, valid1);

    -- LRU update pulse
    --   read (hit or miss): first (low) half of the out state
    --   write hit: the retimed data strobe, but not during a refill
    inv_clk: inverter port map(clk, nclk);
    inv_ref: inverter port map(refill, nrefill);
    rdp_and: and2 port map(rd_done, nclk, upd_rd);
    wrp_and: and2 port map(data_q, nrefill, upd_wr);
    upd_or:  or2  port map(upd_rd, upd_wr, lru_upd);

    -- four LRU bits, one per set: lru(i) = 1 means way 1 is least recently used
    en_and0: and2 port map(block_en(0), lru_upd, lru_wr_en(0));
    en_and1: and2 port map(block_en(1), lru_upd, lru_wr_en(1));
    en_and2: and2 port map(block_en(2), lru_upd, lru_wr_en(2));
    en_and3: and2 port map(block_en(3), lru_upd, lru_wr_en(3));

    -- the way just used is no longer the LRU, so store not way_i
    lru_latch0: positive_dlatch port map(nway, lru_wr_en(0), lru(0), open);
    lru_latch1: positive_dlatch port map(nway, lru_wr_en(1), lru(1), open);
    lru_latch2: positive_dlatch port map(nway, lru_wr_en(2), lru(2), open);
    lru_latch3: positive_dlatch port map(nway, lru_wr_en(3), lru(3), open);

    -- LRU bit of the indexed set
    sel_and0: and2 port map(block_en(0), lru(0), lru_pick(0));
    sel_and1: and2 port map(block_en(1), lru(1), lru_pick(1));
    sel_and2: and2 port map(block_en(2), lru(2), lru_pick(2));
    sel_and3: and2 port map(block_en(3), lru(3), lru_pick(3));
    sel_or01: or2 port map(lru_pick(0), lru_pick(1), pick01);
    sel_or23: or2 port map(lru_pick(2), lru_pick(3), pick23);
    sel_or:   or2 port map(pick01, pick23, lru_sel);

    -- victim = v0 and (not v1 or lru): way 0 if invalid, else way 1 if invalid, else LRU
    inv_v1:  inverter port map(v1, nvalid1);
    vic_or:  or2 port map(nvalid1, lru_sel, t_vic);
    vic_and: and2 port map(v0, t_vic, victim);
    
end structural;
