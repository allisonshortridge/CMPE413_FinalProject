-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:01:54 2026


architecture structural of decoder1to2 is

-- inverter
component inverter
  port (
    input    : in  std_logic;
    output   : out std_logic);
end component;

-- 2-input AND
component and2
    port (
        input1   : in  std_logic;
        input2   : in  std_logic;
        output   : out std_logic
    );
end component;

for inverter_1: inverter use entity work.inverter(structural);
for and2_1, and2_2: and2 use entity work.and2(structural);

signal not_a0: std_logic;

begin
    inverter_1: inverter port map(A0, not_a0);

    and2_1: and2 port map(not_a0, E, Y0);
    and2_2: and2 port map(A0, E, Y1);

end structural;
