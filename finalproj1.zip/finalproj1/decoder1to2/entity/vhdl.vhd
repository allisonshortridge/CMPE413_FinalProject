-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Nov 20 18:01:54 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

-- 1:2 decoder
entity decoder1to2 is
    port (
        A0    : in std_logic;
        E     : in std_logic;
        Y1    : out std_logic;
        Y0    : out std_logic
    );
end decoder1to2;
